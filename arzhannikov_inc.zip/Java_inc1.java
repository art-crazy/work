package com.company;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

public class Java_inc1 {


    public static void main(String[] args) throws FileNotFoundException {


        //String separator = File.separator; // замена разделителя в пути до файла на заданное значение
        // String path = separator + "C:" + separator + "Users" + separator + "artcrazy" + separator + "Desktop" + separator + "new 1"; // помещаем путь в переменную path
        // File file = new File(path); // создаем объект класса File и вкладываем путь до файла

        File file = new File("test.txt"); // создаем объект класса File и указываем название файла. Читается test.txt с директории проекта
        Scanner scanner = new Scanner(file); // входящий поток из file
        Scanner scannerin = new Scanner(System.in);

        System.out.println( "Start" );
        System.out.println( "" );
        System.out.println("On which line are we looking for the word?"); // "На какой строке ищем слово?"
        int lineEnter = scannerin.nextInt();
        System.out.println("What position are we looking for a word in??"); // "На какой позиции ищем слово?"
        int positionEnter = scannerin.nextInt();
        int lines = 0; // счетчик строк
        int wordCount = 0; // счетчик специальных слов

        if ( ( lineEnter > 0 ) && ( positionEnter > 0 ) ) { // если строка и позиция > 0, то продолжаем.

            while (scanner.hasNextLine()) { // пока есть следующая строка

                String array = scanner.nextLine(); // Помещаем строку в переменную array
                String[] wordsString = array.split(" "); // Помещение слов в массив
                String[] character = array.split(""); // Помещение символов в массив
                lines++; // считаем номер строки

                for ( int i = 0; i < character.length; i++ ) { // цикл на определение количества специальных символов

                    if ( character [ i ] .equals ("\\") ) {
                        wordCount++;
                    }
                    if ( character [ i ] .equals (".") ) {
                        wordCount++;
                    }
                    if ( character [ i ] .equals ("[") ) {
                        wordCount++;
                    }
                    if ( character [ i ] .equals ("{") ) {
                        wordCount++;
                    }
                    if ( character [ i ] .equals ("(") ) {
                        wordCount++;
                    }
                    if ( character [ i ] .equals ("*") ) {
                        wordCount++;
                    }
                    if ( character [ i ] .equals ("+") ) {
                        wordCount++;
                    }
                    if ( character [ i ] .equals ("?") ) {
                        wordCount++;
                    }
                    if ( character [ i ] .equals ("^") ) {
                        wordCount++;
                    }
                    if ( character [ i ] .equals ("$") ) {
                        wordCount++;
                    }
                    if ( character [ i ] .equals ("|") ) {
                        wordCount++;
                    }
                }

                if ( lines == 1 ) { // Вывод длины массива первой строки
                    System.out.println( "Number of words in the first line: " + wordsString.length ); // "Количество слов в первой строке: ". Длина массива первой строки будет равна количеству слов
                }

                if ( ( lines == lineEnter ) & wordsString[0].equals("") ) { // если номер строки совпадает с введенным номером строки & строка пуста
                    System.out.println( "error. The line is empty" ); break; // "error. Строка пуста"
                } else if ( ( lines == lineEnter ) & ( positionEnter <= wordsString.length ) ) { // если номер строки совпадает с введенным номером строки & позиция слова не больше длины строки
                    System.out.println( "Found a word on line " + lines + " at " + positionEnter + " position: " + wordsString[ positionEnter - 1] ); // "Найдено слово на строке №" "на" "позиции"

                }

                if ( ( lines == lineEnter ) & ( positionEnter > wordsString.length ) ) { // error. Введенная позиция больше, чем количество слов в строке
                    System.out.println( "error. The entered position is greater than the number of words per line. In a string of words " + wordsString.length + " words" ); // "Введенная позиция больше, чем количество слов в строке. В строке слов"
                }

            }

            System.out.println( "Number of special characters: " + wordCount + ". I took them for special characters: \\ . [ { ( * + ? ^ $ | "); // "Количество сециальных символов:" "За специальные символы принял:"

            if ( ( lineEnter > lines ) & ( lines != 0 ) ) {
                System.out.println( "error. The entered string value is greater than the number of rows in the file. The file has " + lines + " lines" ); // "Введенное значение строки больше, чем количество строк в файле. В файле .. строк(а)"
            }

            if ( lines == 0 ) {
                System.out.println( "error. Empty string" ); // "Пустые строки"
            }

            scanner.close();

            System.out.println( "" );
            System.out.println( "End" );
        } else System.out.println( "error. Enter a negative or null value. Try again" ); // "Введенно отрицательное, либо нулевое значение. Повтори попытку"

    }
}